package schedule

class PersonAController {

	def scaffold = true
//    def index() { }
}
